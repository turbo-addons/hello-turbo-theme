<?php
/**
 * Page Layout — Content width per content type, page title, etc.
 *
 * @package Turbo_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function turbo_customizer_page_layout( $wp_customize ) {

	$wp_customize->add_section( 'turbo_page_layout', array(
		'title'    => __( 'Page Layout', 'helloturbo' ),
		'priority' => 29,
	) );

	// Page content layout.
	$wp_customize->add_setting( 'turbo_page_content_layout', array(
		'default' => 'normal', 'sanitize_callback' => 'turbo_sanitize_select',
	) );
	$wp_customize->add_control( 'turbo_page_content_layout', array(
		'label'   => __( 'Page Content Layout', 'helloturbo' ),
		'section' => 'turbo_page_layout',
		'type'    => 'select',
		'choices' => array(
			'normal'     => __( 'Normal', 'helloturbo' ),
			'narrow'     => __( 'Narrow', 'helloturbo' ),
			'full-width' => __( 'Full Width / Stretched', 'helloturbo' ),
		),
	) );

	// Page title.
	$wp_customize->add_setting( 'turbo_page_title_enable', array(
		'default' => true, 'sanitize_callback' => 'turbo_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'turbo_page_title_enable', array(
		'label'   => __( 'Show Page Title', 'helloturbo' ),
		'section' => 'turbo_page_layout',
		'type'    => 'checkbox',
	) );

	// Page title style.
	$wp_customize->add_setting( 'turbo_page_title_style', array(
		'default' => 'inline', 'sanitize_callback' => 'turbo_sanitize_select',
	) );
	$wp_customize->add_control( 'turbo_page_title_style', array(
		'label'   => __( 'Page Title Style', 'helloturbo' ),
		'section' => 'turbo_page_layout',
		'type'    => 'select',
		'choices' => array(
			'inline'   => __( 'Inline (inside content)', 'helloturbo' ),
			'banner'   => __( 'Full-width Banner', 'helloturbo' ),
		),
	) );

	$wp_customize->add_setting( 'turbo_page_title_align', array(
		'default' => 'left', 'sanitize_callback' => 'turbo_sanitize_select',
	) );
	$wp_customize->add_control( 'turbo_page_title_align', array(
		'label'   => __( 'Page Title Alignment', 'helloturbo' ),
		'section' => 'turbo_page_layout',
		'type'    => 'select',
		'choices' => array(
			'left'   => __( 'Left', 'helloturbo' ),
			'center' => __( 'Center', 'helloturbo' ),
			'right'  => __( 'Right', 'helloturbo' ),
		),
	) );

	// Featured image on pages.
	$wp_customize->add_setting( 'turbo_page_featured_image', array(
		'default' => false, 'sanitize_callback' => 'turbo_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'turbo_page_featured_image', array(
		'label'   => __( 'Show Featured Image on Pages', 'helloturbo' ),
		'section' => 'turbo_page_layout',
		'type'    => 'checkbox',
	) );

	// Comments on pages.
	$wp_customize->add_setting( 'turbo_page_comments', array(
		'default' => true, 'sanitize_callback' => 'turbo_sanitize_checkbox',
	) );
	$wp_customize->add_control( 'turbo_page_comments', array(
		'label'   => __( 'Enable Comments on Pages', 'helloturbo' ),
		'section' => 'turbo_page_layout',
		'type'    => 'checkbox',
	) );
}
add_action( 'customize_register', 'turbo_customizer_page_layout' );
